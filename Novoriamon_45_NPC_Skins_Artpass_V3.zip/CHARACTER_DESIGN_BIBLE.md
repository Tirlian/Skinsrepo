# Novoriamon – Charakterdesign V3

## Freya (freya)
Rolle: Hauptfiguren. Frisur: **spiked**. Outfit: **asym_jacket**. Hauptfarbe RGB (44, 146, 122); Akzent RGB (252, 239, 222).

## Kian (kian)
Rolle: Hauptfiguren. Frisur: **asym_bangs**. Outfit: **racing**. Hauptfarbe RGB (62, 76, 97); Akzent RGB (54, 57, 70).

## Maren (gym_normal)
Rolle: Arenaleiter · Normal. Frisur: **bob**. Outfit: **vest**. Hauptfarbe RGB (154, 131, 111); Akzent RGB (252, 239, 222).

## Kael (gym_fire)
Rolle: Arenaleiter · Feuer. Frisur: **side_shave**. Outfit: **racing**. Hauptfarbe RGB (170, 61, 53); Akzent RGB (54, 57, 70).

## Nerina (gym_water)
Rolle: Arenaleiter · Wasser. Frisur: **swept**. Outfit: **longcoat**. Hauptfarbe RGB (126, 216, 235); Akzent RGB (49, 52, 65).

## Volt (gym_electric)
Rolle: Arenaleiter · Elektro. Frisur: **messy**. Outfit: **techwear**. Hauptfarbe RGB (50, 60, 87); Akzent RGB (54, 57, 70).

## Silva (gym_grass)
Rolle: Arenaleiter · Pflanze. Frisur: **parted**. Outfit: **poncho**. Hauptfarbe RGB (52, 111, 72); Akzent RGB (252, 239, 222).

## Eira (gym_ice)
Rolle: Arenaleiter · Eis. Frisur: **long**. Outfit: **capelet**. Hauptfarbe RGB (90, 143, 167); Akzent RGB (54, 57, 70).

## Ryo (gym_fighting)
Rolle: Arenaleiter · Kampf. Frisur: **tied**. Outfit: **vest**. Hauptfarbe RGB (240, 161, 138); Akzent RGB (49, 52, 65).

## Vesper (gym_poison)
Rolle: Arenaleiter · Gift. Frisur: **fluffy**. Outfit: **street**. Hauptfarbe RGB (85, 58, 115); Akzent RGB (54, 57, 70).

## Daria (gym_ground)
Rolle: Arenaleiter · Boden. Frisur: **cropped**. Outfit: **expedition**. Hauptfarbe RGB (139, 98, 64); Akzent RGB (252, 239, 222).

## Aeron (gym_flying)
Rolle: Arenaleiter · Flug. Frisur: **fringe**. Outfit: **utility**. Hauptfarbe RGB (66, 107, 135); Akzent RGB (54, 57, 70).

## Selene (gym_psychic)
Rolle: Arenaleiter · Psycho. Frisur: **undercut**. Outfit: **kimono**. Hauptfarbe RGB (242, 178, 239); Akzent RGB (49, 52, 65).

## Tilio (gym_bug)
Rolle: Arenaleiter · Käfer. Frisur: **wavy**. Outfit: **overalls**. Hauptfarbe RGB (82, 105, 59); Akzent RGB (54, 57, 70).

## Garron (gym_rock)
Rolle: Arenaleiter · Gestein. Frisur: **braided**. Outfit: **armor**. Hauptfarbe RGB (108, 114, 119); Akzent RGB (252, 239, 222).

## Noctis (gym_ghost)
Rolle: Arenaleiter · Geist. Frisur: **spiked**. Outfit: **longcoat**. Hauptfarbe RGB (60, 56, 90); Akzent RGB (54, 57, 70).

## Draven (gym_dragon)
Rolle: Arenaleiter · Drache. Frisur: **asym_bangs**. Outfit: **tailcoat**. Hauptfarbe RGB (178, 173, 242); Akzent RGB (49, 52, 65).

## Raven (gym_dark)
Rolle: Arenaleiter · Unlicht. Frisur: **bob**. Outfit: **street**. Hauptfarbe RGB (36, 44, 61); Akzent RGB (54, 57, 70).

## Ferris (gym_steel)
Rolle: Arenaleiter · Stahl. Frisur: **side_shave**. Outfit: **armor**. Hauptfarbe RGB (88, 111, 121); Akzent RGB (252, 239, 222).

## Faye (gym_fairy)
Rolle: Arenaleiter · Fee. Frisur: **swept**. Outfit: **capelet**. Hauptfarbe RGB (172, 116, 158); Akzent RGB (54, 57, 70).

## Tirlian – Top 4 (league_tirlian)
Rolle: Liga. Frisur: **messy**. Outfit: **formal**. Hauptfarbe RGB (225, 182, 94); Akzent RGB (49, 52, 65).

## Cassia – Top 4 (league_cassia)
Rolle: Liga. Frisur: **parted**. Outfit: **kimono**. Hauptfarbe RGB (115, 74, 92); Akzent RGB (252, 239, 222).

## Orion – Top 4 (league_orion)
Rolle: Liga. Frisur: **long**. Outfit: **overalls**. Hauptfarbe RGB (52, 77, 105); Akzent RGB (54, 57, 70).

## Lys – Top 4 (league_lys)
Rolle: Liga. Frisur: **tied**. Outfit: **poncho**. Hauptfarbe RGB (75, 101, 113); Akzent RGB (252, 239, 222).

## Champion (Arbeitstitel) (league_champion)
Rolle: Liga. Frisur: **fluffy**. Outfit: **tailcoat**. Hauptfarbe RGB (237, 197, 115); Akzent RGB (49, 52, 65).

## Aster (nova_aster)
Rolle: Team Nova. Frisur: **cropped**. Outfit: **tailcoat**. Hauptfarbe RGB (185, 84, 120); Akzent RGB (49, 52, 65).

## Lyra (nova_lyra)
Rolle: Team Nova. Frisur: **fringe**. Outfit: **longcoat**. Hauptfarbe RGB (205, 93, 154); Akzent RGB (49, 52, 65).

## Varek (nova_varek)
Rolle: Team Nova. Frisur: **undercut**. Outfit: **techwear**. Hauptfarbe RGB (191, 93, 142); Akzent RGB (49, 52, 65).

## Korr – Kommandant (nova_korr)
Rolle: Team Nova. Frisur: **wavy**. Outfit: **asym_jacket**. Hauptfarbe RGB (53, 49, 69); Akzent RGB (54, 57, 70).

## Team-Nova-Rüpel 1 (nova_grunt_01)
Rolle: Team Nova – Rüpel. Frisur: **braided**. Outfit: **vest**. Hauptfarbe RGB (53, 48, 63); Akzent RGB (54, 57, 70).

## Team-Nova-Rüpel 2 (nova_grunt_02)
Rolle: Team Nova – Rüpel. Frisur: **spiked**. Outfit: **layered**. Hauptfarbe RGB (75, 53, 75); Akzent RGB (252, 239, 222).

## Team-Nova-Rüpel 3 (nova_grunt_03)
Rolle: Team Nova – Rüpel. Frisur: **asym_bangs**. Outfit: **tailcoat**. Hauptfarbe RGB (225, 108, 148); Akzent RGB (49, 52, 65).

## Team-Nova-Rüpel 4 (nova_grunt_04)
Rolle: Team Nova – Rüpel. Frisur: **bob**. Outfit: **utility**. Hauptfarbe RGB (75, 53, 75); Akzent RGB (54, 57, 70).

## Professor Elian (research_elian)
Rolle: Forschung. Frisur: **side_shave**. Outfit: **longcoat**. Hauptfarbe RGB (61, 158, 170); Akzent RGB (49, 52, 65).

## Archivarin Mira (research_mira)
Rolle: Forschung. Frisur: **swept**. Outfit: **layered**. Hauptfarbe RGB (99, 114, 132); Akzent RGB (252, 239, 222).

## Expeditionsleiterin Rhea (research_rhea)
Rolle: Forschung. Frisur: **messy**. Outfit: **expedition**. Hauptfarbe RGB (105, 118, 76); Akzent RGB (54, 57, 70).

## Fossilassistent (research_fossil)
Rolle: Forschung. Frisur: **parted**. Outfit: **overalls**. Hauptfarbe RGB (206, 211, 215); Akzent RGB (252, 239, 222).

## Center-Leitung (quest_healer)
Rolle: Quest-NPCs. Frisur: **long**. Outfit: **hoodie**. Hauptfarbe RGB (231, 216, 219); Akzent RGB (252, 239, 222).

## Reiseführerin (quest_guide)
Rolle: Quest-NPCs. Frisur: **tied**. Outfit: **expedition**. Hauptfarbe RGB (73, 107, 135); Akzent RGB (252, 239, 222).

## Händler (quest_merchant)
Rolle: Quest-NPCs. Frisur: **fluffy**. Outfit: **kimono**. Hauptfarbe RGB (136, 104, 70); Akzent RGB (54, 57, 70).

## Stadthistoriker (quest_historian)
Rolle: Quest-NPCs. Frisur: **cropped**. Outfit: **overalls**. Hauptfarbe RGB (178, 199, 215); Akzent RGB (49, 52, 65).

## Minenaufseherin (quest_miner)
Rolle: Quest-NPCs. Frisur: **fringe**. Outfit: **poncho**. Hauptfarbe RGB (115, 96, 76); Akzent RGB (54, 57, 70).

## Ranger (quest_ranger)
Rolle: Quest-NPCs. Frisur: **undercut**. Outfit: **armor**. Hauptfarbe RGB (64, 103, 79); Akzent RGB (54, 57, 70).

## Ingenieurin (quest_engineer)
Rolle: Quest-NPCs. Frisur: **wavy**. Outfit: **formal**. Hauptfarbe RGB (86, 99, 115); Akzent RGB (252, 239, 222).

## Reisender (quest_traveler)
Rolle: Quest-NPCs. Frisur: **braided**. Outfit: **techwear**. Hauptfarbe RGB (102, 127, 156); Akzent RGB (54, 57, 70).

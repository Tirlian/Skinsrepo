# EasyNPC-Installation

Importiere die PNG-Dateien aus `skins/` als benutzerdefinierte NPC-Texturen. Wähle **Classic/Steve** (4-Pixel-Arme). Wenn deine EasyNPC-Version statt Dateien URLs benötigt, lade die Skin-PNGs auf GitHub hoch und verwende die jeweiligen `raw.githubusercontent.com`-URLs.

Behalte die bestehenden NPC-IDs bei; Referenzen stehen in `SKIN_ZUORDNUNG.csv`. Teste zunächst `freya.png`, `kian.png`, `nova_aster.png` und `gym_fire.png` ingame. Kontrolliere Kopf/Haare, Seiten, Arme und die äußere Texturebene.

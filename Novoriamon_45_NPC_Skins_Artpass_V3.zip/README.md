# Novoriamon – NPC Skin Artpass V3

45 aktualisierte Minecraft-Skintexturen mit unveränderten IDs. Individuelle Kleidungsschnitte, Akzent-Motive, Schuhpartien, Haarformen und neue flache Kontrollansichten. Dies ist ein wesentlich variierter **programmatischer Artpass**, nicht die durch einen Künstler bestätigte endgültige Premiumkollektion.

Siehe `QUALITY_REPORT.md` und `INSTALLATION.md`.
